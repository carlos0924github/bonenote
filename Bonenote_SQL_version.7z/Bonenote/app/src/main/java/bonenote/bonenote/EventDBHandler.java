package bonenote.bonenote;

/**
 * Created by pc235 on 2016/4/20.
 */
public class EventDBHandler {
    // Database Version
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "EventDB";
    // Contacts table name
    private static final String TABLE_EVENTS = "Events";
    // Shops Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_TOPIC = "topic";
    private static final String KEY_ADDRESS = "address";
    private static final String KEY_SUCCESS = "success";
    private static final String KEY_CATEGORY = "category";
    private static final String KEY_WEIGHT = "weight";
    private static final String KEY_TIME = "time";
    private static final String KEY_REMIND = "remind";

}
