package bonenote.bonenote;

public class Event {
    private int id;
    private String topic;
    private String address;
    private String category;
    private int weight;
    private String time;
    private int remind;
    private int success;

    public Event() {
    }

    public Event(int id, String topic, String address, String category, int weight, String time, int remind, int success) {
        this.id = id;
        this.topic = topic;
        this.address = address;
        this.category = category;
        this.weight = weight;
        this.time = time;
        this.remind = remind;


    }

    //set method
    public void setId(int id) {
        this.id = id;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setRemind(int remind) {
        this.remind = remind;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    //get  method
    public int getId() {
        return id;
    }

    public String getTopic(String topic) {
        return topic;
    }

    public String getAddress(String address) {
        return address;
    }

    public String getCategory(String category) {
        return category;
    }

    public int getWeight(int weight) {
        return weight;
    }

    public String getTime(String time) {
        return time;
    }

    public int getRemind(int remind) {
        return remind;
    }

    public int getSuccess(int success) {
        return success;
    }

}